/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
      domains: ['cdn.sanity.io']
    },
    //
output:"export",
    //
  }
  
  module.exports = nextConfig