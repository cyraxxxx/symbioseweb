import resource from './resource.schema';
import resourcePlaylist from './resource-playlist.schema';

const schemas = [resource, resourcePlaylist]

export default schemas;